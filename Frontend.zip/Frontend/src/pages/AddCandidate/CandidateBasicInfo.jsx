export default function CandidateBasicInfo({ data, setData }) {
  const set = (k) => (e) => setData((d) => ({ ...d, [k]: e.target.value }));
  const setLoc = (k) => (e) =>
    setData((d) => ({ ...d, location: { ...d.location, [k]: e.target.value } }));

  return (
    <div className="grid2">
      <label className="full">Full name *
        <input value={data.fullName} onChange={set("fullName")} placeholder="e.g. Rahul Sharma" autoFocus />
      </label>
      <label>Email
        <input type="email" value={data.email} onChange={set("email")} placeholder="name@example.com" />
      </label>
      <label>Phone
        <input value={data.phone} onChange={set("phone")} placeholder="+91 98765 43210" />
      </label>
      <label>City
        <input value={data.location.city} onChange={setLoc("city")} />
      </label>
      <label>State
        <input value={data.location.state} onChange={setLoc("state")} />
      </label>
      <label>Country
        <input value={data.location.country} onChange={setLoc("country")} />
      </label>
    </div>
  );
}
